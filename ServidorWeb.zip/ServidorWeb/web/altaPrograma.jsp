<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.Html" %>
<%@ page import="java.util.List" %>
<%@ page import="Logica.Entidades.Curso" %>
<jsp:include page="header.jsp" />

<%
    List<Curso> cursos = (List<Curso>) request.getAttribute("cursos");
    List<String> cursosSel = (List<String>) request.getAttribute("v_cursos");
%>

<div class="home-layout">
    <jsp:include page="sidebarIzq.jsp" />

    <div class="home-content">
        <div class="auth-box auth-box-large" style="margin-top:0;">
            <h2>Alta de Programa de Formación</h2>
            <p class="auth-subtitle">Registra un nuevo programa de formación</p>

            <% if (request.getAttribute("error") != null) { %>
            <div class="alert alert-error"><%= Html.esc(request.getAttribute("error")) %></div>
            <% } %>

            <form action="<%= request.getContextPath() %>/alta-programa" method="post" enctype="multipart/form-data" class="row g-3">

                <div class="col-12">
                    <label for="nombre" class="form-label">Nombre (único):</label>
                    <input type="text" class="form-control" id="nombre" name="nombre" required maxlength="100"
                           value="<%= Html.esc(request.getAttribute("v_nombre")) %>">
                </div>

                <div class="col-12">
                    <label for="descripcion" class="form-label">Descripción:</label>
                    <textarea class="form-control" id="descripcion" name="descripcion" rows="3" required><%= Html.esc(request.getAttribute("v_descripcion")) %></textarea>
                </div>

                <div class="col-md-6">
                    <label for="fechaInicio" class="form-label">Fecha de inicio:</label>
                    <input type="date" class="form-control" id="fechaInicio" name="fechaInicio" required
                           value="<%= Html.esc(request.getAttribute("v_fInicio")) %>">
                </div>

                <div class="col-md-6">
                    <label for="fechaFin" class="form-label">Fecha de fin:</label>
                    <input type="date" class="form-control" id="fechaFin" name="fechaFin" required
                           value="<%= Html.esc(request.getAttribute("v_fFin")) %>">
                </div>
                
                <div class="col-12">
                    <label class="form-label">Cursos del programa <span class="text-muted">(opcional, podés agregarlos después)</span></label>
                    <% if (cursos == null || cursos.isEmpty()) { %>
                        <p class="text-muted">Todavia no hay cursos en la plataforma.</p>
                    <% } else { %>
                        <div class="list-group" style="max-height:220px; overflow-y:auto;">
                            <% for (Curso c : cursos) { %>
                                <label class="list-group-item d-flex justify-content-between align-items-center">
                                <span>
                                    <input class="form-check-input me-2" type="checkbox" name="curso"
                                            value="<%= Html.esc(c.getNombre()) %>"
                                            <%= (cursosSel != null && cursosSel.contains(c.getNombre())) ? "checked" : "" %>>
                                    <%= Html.esc(c.getNombre()) %>
                                </span>
                                <span class="badge text-bg-secondary">
                                    <%= c.getInstituto() != null ? Html.esc(c.getInstituto().getNombre()) : "General" %>
                                </span>
                                </label>
                            <% } %>
                        </div>
                    <% } %>
                </div>
                <div class="col-12">
                    <label for="imagenArchivo" class="form-label">Imagen desde tu PC (opcional):</label>
                    <input type="file" class="form-control" id="imagenArchivo" name="imagenArchivo"
                            accept="image/jpeg,image/png">
                    <small class="text-muted">
                        JPG o PNG, hasta 5 MB. Elegí un archivo o ingresá una URL, no ambas.
                        Si el formulario vuelve con un error, seleccioná el archivo nuevamente.
                    </small>
                </div>

                <div class="col-12">
                    <label for="imagen" class="form-label">URL de la imagen (opcional):</label>
                    <input type="url" class="form-control" id="imagen" name="imagen" placeholder="https://..."
                        value="<%= Html.esc(request.getAttribute("v_imagen")) %>">
                </div>
                <div class="col-6">
                    <a href="<%= request.getContextPath() %>/index.jsp" class="btn btn-danger w-100 text-center">Cancelar</a>
                </div>
                <div class="col-6">
                    <button type="submit" class="btn btn-primary w-100">Aceptar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<jsp:include page="footer.jsp" />