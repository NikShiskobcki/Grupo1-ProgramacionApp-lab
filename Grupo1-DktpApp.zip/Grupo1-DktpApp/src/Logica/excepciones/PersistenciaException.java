/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica.excepciones;

public class PersistenciaException extends RuntimeException{
    public PersistenciaException(String mensaje, Throwable motivo){
        super(mensaje, motivo);
    }
    
}
