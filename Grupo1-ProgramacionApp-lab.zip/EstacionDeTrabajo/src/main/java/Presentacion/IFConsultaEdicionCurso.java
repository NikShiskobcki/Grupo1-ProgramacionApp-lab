/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package Presentacion;

import Logica.DTO.DetalleEdicionCurso;
import Logica.DTO.InscripcionResumen;
import Logica.Entidades.Curso;
import Logica.Entidades.EdicionCurso;
import Logica.Entidades.Instituto;
import Logica.controladores.IControlador;
import java.util.List;
import javax.swing.DefaultListModel;

/**
 *
 * @author xnahu
 */
public class IFConsultaEdicionCurso extends javax.swing.JInternalFrame {
    private IControlador controlador;
    /**
     * Creates new form IFConsultaEdicionCurso
     */
    public IFConsultaEdicionCurso(IControlador controlador) {
        initComponents();
         this.controlador = controlador;

    cmbInstituto.removeAllItems();
    cmbInstituto.addItem("Seleccione un instituto...");

    cmbCurso.removeAllItems();
    cmbCurso.addItem("Seleccione primero un instituto...");
    cmbCurso.setEnabled(false);

    cmbEdicion.removeAllItems();
    cmbEdicion.addItem("Seleccione primero un curso...");
    cmbEdicion.setEnabled(false);

    cargarInstitutos();
    }
    
    private void cargarInstitutos() {

    List<Instituto> institutos = controlador.listarInstitutos();

    for (Instituto instituto : institutos) {
        cmbInstituto.addItem(instituto.getNombre());
    }
}
    private void cargarCursosPorInstituto() {

    cmbCurso.removeAllItems();

    cmbEdicion.removeAllItems();
    cmbEdicion.addItem("Seleccione primero un curso...");
    cmbEdicion.setEnabled(false);

    if (cmbInstituto.getSelectedIndex() <= 0) {
        cmbCurso.addItem("Seleccione primero un instituto...");
        cmbCurso.setEnabled(false);
        return;
    }

    String nombreInstituto = cmbInstituto.getSelectedItem().toString();

    List<Curso> cursos =controlador.listarCursosPorInstituto(nombreInstituto);

    if (cursos.isEmpty()) {
        cmbCurso.addItem("No hay cursos disponibles");
        cmbCurso.setEnabled(false);
        return;
    }

    cmbCurso.addItem("Seleccione un curso...");

    for (Curso curso : cursos) {
        cmbCurso.addItem(curso.getNombre());
    }

    cmbCurso.setEnabled(true);
}
    private void cargarEdicionesPorCurso() {

    cmbEdicion.removeAllItems();

    if (!cmbCurso.isEnabled() || cmbCurso.getSelectedIndex() <= 0) {
        cmbEdicion.addItem("Seleccione primero un curso...");
        cmbEdicion.setEnabled(false);
        return;
    }

    String nombreCurso = cmbCurso.getSelectedItem().toString();

    List<EdicionCurso> ediciones =
            controlador.listarEdicionesPorCurso(nombreCurso);

    if (ediciones.isEmpty()) {
        cmbEdicion.addItem("No hay ediciones disponibles");
        cmbEdicion.setEnabled(false);
        return;
    }

    cmbEdicion.addItem("Seleccione una edición...");

    for (EdicionCurso edicion : ediciones) {
        cmbEdicion.addItem(edicion.getNombre());
    }

    cmbEdicion.setEnabled(true);
}
   
    private void limpiarDatosEdicion() {

    txtNombre.setText("");
    txtFechaInicio.setText("");
    txtFechaFin.setText("");
    txtCupo.setText("");
    txtFechaPublicacion.setText("");
    txtInscriptos.setText("");

    lstDocentes.setModel(new DefaultListModel<>());
    lblCategoriasValor.setText("");
    lstEstudiantes.setModel(new DefaultListModel<>());
    
}
    
    private void mostrarDatosEdicion() {

    if (!cmbEdicion.isEnabled() || cmbEdicion.getSelectedIndex() <= 0) {
        limpiarDatosEdicion();
        return;
    }

    String nombreEdicion = cmbEdicion.getSelectedItem().toString();

    DetalleEdicionCurso detalle =
            controlador.consultarEdicion(nombreEdicion);

    if (detalle == null) {
        limpiarDatosEdicion();
        return;
    }

    txtNombre.setText(detalle.getNombre());
    txtFechaInicio.setText(detalle.getFechaInicio().toString());
    txtFechaFin.setText(detalle.getFechaFin().toString());

    if (detalle.getCupo() == null) {
        txtCupo.setText("Sin límite");
    } else {
        txtCupo.setText(detalle.getCupo().toString());
    }

    txtFechaPublicacion.setText(
            detalle.getFechaPublicacion().toString()
    );

    txtInscriptos.setText(String.valueOf(detalle.getCantidadInscriptos()));

    lblCategoriasValor.setText(
            detalle.getCategorias() == null || detalle.getCategorias().isEmpty()
                    ? "(sin categorías)"
                    : String.join(", ", detalle.getCategorias()));

    DefaultListModel<String> modelo = new DefaultListModel<>();

    for (String docente : detalle.getDocentes()) {
        modelo.addElement(docente);
    }
    
        List<InscripcionResumen> inscripciones
                = controlador.listarInscripcionesPorEdicion(nombreEdicion, false);

        DefaultListModel<String> modeloEstudiantes = new DefaultListModel<>();

        for (InscripcionResumen inscripcion : inscripciones) {
            modeloEstudiantes.addElement(
                    inscripcion.getNombreEstudiante()
                    + " (" + inscripcion.getNicknameEstudiante() + ")"
                    + " - " + inscripcion.getEstado()
            );
        }

        lstEstudiantes.setModel(modeloEstudiantes);

        lstDocentes.setModel(modelo);
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cmbInstituto = new javax.swing.JComboBox<>();
        cmbCurso = new javax.swing.JComboBox<>();
        cmbEdicion = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtFechaInicio = new javax.swing.JTextField();
        txtFechaFin = new javax.swing.JTextField();
        txtCupo = new javax.swing.JTextField();
        txtFechaPublicacion = new javax.swing.JTextField();
        txtInscriptos = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        usersSeparator9 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstDocentes = new javax.swing.JList<>();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblUsuarios = new javax.swing.JLabel();
        lblUsuarios1 = new javax.swing.JLabel();
        usersSeparator1 = new javax.swing.JSeparator();
        usersSeparator2 = new javax.swing.JSeparator();
        usersSeparator3 = new javax.swing.JSeparator();
        usersSeparator4 = new javax.swing.JSeparator();
        usersSeparator5 = new javax.swing.JSeparator();
        usersSeparator6 = new javax.swing.JSeparator();
        usersSeparator7 = new javax.swing.JSeparator();
        usersSeparator8 = new javax.swing.JSeparator();
        jLabel12 = new javax.swing.JLabel();
        lblCategoriasTitulo = new javax.swing.JLabel();
        lblCategoriasValor = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        lstEstudiantes = new javax.swing.JList<>();

        setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        setPreferredSize(new java.awt.Dimension(910, 950));
        setVisible(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cmbInstituto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbInstituto.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        cmbInstituto.addActionListener(this::cmbInstitutoActionPerformed);
        getContentPane().add(cmbInstituto, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 100, 350, 30));

        cmbCurso.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbCurso.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        cmbCurso.addActionListener(this::cmbCursoActionPerformed);
        getContentPane().add(cmbCurso, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 140, 350, 30));

        cmbEdicion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbEdicion.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        cmbEdicion.addActionListener(this::cmbEdicionActionPerformed);
        getContentPane().add(cmbEdicion, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 180, 350, 30));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(35, 71, 75));
        jLabel1.setText("Instituto: ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 110, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(35, 71, 75));
        jLabel2.setText("Curso: ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 150, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(35, 71, 75));
        jLabel3.setText("Edición: ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 190, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(35, 71, 75));
        jLabel4.setText("DATOS DE LA EDICIÓN");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 240, -1, -1));

        txtNombre.setEditable(false);
        txtNombre.setText("jTextField1");
        txtNombre.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        txtNombre.setPreferredSize(new java.awt.Dimension(220, 26));
        getContentPane().add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 260, 270, 30));

        txtFechaInicio.setEditable(false);
        txtFechaInicio.setText("jTextField2");
        txtFechaInicio.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        txtFechaInicio.setPreferredSize(new java.awt.Dimension(120, 26));
        getContentPane().add(txtFechaInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 300, 270, 30));

        txtFechaFin.setEditable(false);
        txtFechaFin.setText("jTextField3");
        txtFechaFin.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        txtFechaFin.setPreferredSize(new java.awt.Dimension(120, 26));
        getContentPane().add(txtFechaFin, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 340, 270, 30));

        txtCupo.setEditable(false);
        txtCupo.setText("jTextField4");
        txtCupo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        txtCupo.setPreferredSize(new java.awt.Dimension(80, 26));
        getContentPane().add(txtCupo, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 380, 270, 30));

        txtFechaPublicacion.setEditable(false);
        txtFechaPublicacion.setText("jTextField5");
        txtFechaPublicacion.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        txtFechaPublicacion.setPreferredSize(new java.awt.Dimension(120, 26));
        getContentPane().add(txtFechaPublicacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 460, 270, 30));

        txtInscriptos.setEditable(false);
        txtInscriptos.setText("jTextField6");
        txtInscriptos.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        txtInscriptos.setPreferredSize(new java.awt.Dimension(80, 26));
        getContentPane().add(txtInscriptos, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 420, 270, 30));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(35, 71, 75));
        jLabel11.setText("Inscriptos:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 430, -1, -1));

        usersSeparator9.setForeground(new java.awt.Color(35, 71, 75));
        getContentPane().add(usersSeparator9, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 450, 270, 10));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(35, 71, 75));
        jLabel5.setText("DOCENTES: ");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 240, 100, -1));

        lstDocentes.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(lstDocentes);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 270, 300, 150));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(35, 71, 75));
        jLabel6.setText("Nombre:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 270, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(35, 71, 75));
        jLabel7.setText("Fecha de inicio:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 310, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(35, 71, 75));
        jLabel8.setText("Fecha de fin:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 350, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(35, 71, 75));
        jLabel9.setText("Cupo:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 390, -1, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(35, 71, 75));
        jLabel10.setText("Fecha publicación:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 470, -1, -1));

        jPanel2.setBackground(new java.awt.Color(35, 71, 75));

        lblUsuarios.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblUsuarios.setForeground(new java.awt.Color(206, 206, 206));
        lblUsuarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Presentacion/usuarios_white_32px.png"))); // NOI18N
        lblUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUsuariosMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblUsuariosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblUsuariosMouseExited(evt);
            }
        });

        lblUsuarios1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblUsuarios1.setForeground(new java.awt.Color(255, 255, 255));
        lblUsuarios1.setText("Consulta Edicion de Curso");
        lblUsuarios1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUsuarios1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblUsuarios1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblUsuarios1MouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblUsuarios)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblUsuarios1, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(605, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblUsuarios, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
                    .addComponent(lblUsuarios1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 910, 60));

        usersSeparator1.setForeground(new java.awt.Color(35, 71, 75));
        getContentPane().add(usersSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 490, 270, 10));

        usersSeparator2.setForeground(new java.awt.Color(35, 71, 75));
        getContentPane().add(usersSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 130, 350, 10));

        usersSeparator3.setForeground(new java.awt.Color(35, 71, 75));
        getContentPane().add(usersSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 170, 350, 10));

        usersSeparator4.setForeground(new java.awt.Color(35, 71, 75));
        getContentPane().add(usersSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 210, 350, 10));

        usersSeparator5.setForeground(new java.awt.Color(35, 71, 75));
        getContentPane().add(usersSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 290, 270, 10));

        usersSeparator6.setForeground(new java.awt.Color(35, 71, 75));
        getContentPane().add(usersSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 330, 270, 10));

        usersSeparator7.setForeground(new java.awt.Color(35, 71, 75));
        getContentPane().add(usersSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 370, 270, 10));

        usersSeparator8.setForeground(new java.awt.Color(35, 71, 75));
        getContentPane().add(usersSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 410, 270, 10));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(35, 71, 75));
        jLabel12.setText("ESTUDIANTES: ");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 430, 100, -1));

        lblCategoriasTitulo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblCategoriasTitulo.setForeground(new java.awt.Color(35, 71, 75));
        lblCategoriasTitulo.setText("Categorías:");
        getContentPane().add(lblCategoriasTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 510, -1, -1));

        getContentPane().add(lblCategoriasValor, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 510, 270, -1));


        lstEstudiantes.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(lstEstudiantes);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 460, 300, 150));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbInstitutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbInstitutoActionPerformed
         cargarCursosPorInstituto();
    }//GEN-LAST:event_cmbInstitutoActionPerformed

    private void cmbCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCursoActionPerformed
            cargarEdicionesPorCurso();

    }//GEN-LAST:event_cmbCursoActionPerformed

    private void cmbEdicionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbEdicionActionPerformed
        mostrarDatosEdicion();
    }//GEN-LAST:event_cmbEdicionActionPerformed

    private void lblConsultaEdicionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblConsultaEdicionMouseClicked

    }//GEN-LAST:event_lblConsultaEdicionMouseClicked

    private void lblConsultaEdicionMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblConsultaEdicionMouseEntered

    }//GEN-LAST:event_lblConsultaEdicionMouseEntered

    private void lblConsultaEdicionMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblConsultaEdicionMouseExited

    }//GEN-LAST:event_lblConsultaEdicionMouseExited

    private void lblUsuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUsuariosMouseClicked

    }//GEN-LAST:event_lblUsuariosMouseClicked

    private void lblUsuariosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUsuariosMouseEntered

    }//GEN-LAST:event_lblUsuariosMouseEntered

    private void lblUsuariosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUsuariosMouseExited

    }//GEN-LAST:event_lblUsuariosMouseExited

    private void lblUsuarios1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUsuarios1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_lblUsuarios1MouseClicked

    private void lblUsuarios1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUsuarios1MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_lblUsuarios1MouseEntered

    private void lblUsuarios1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUsuarios1MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_lblUsuarios1MouseExited


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbCurso;
    private javax.swing.JComboBox<String> cmbEdicion;
    private javax.swing.JComboBox<String> cmbInstituto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel lblCategoriasTitulo;
    private javax.swing.JLabel lblCategoriasValor;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblUsuarios;
    private javax.swing.JLabel lblUsuarios1;
    private javax.swing.JList<String> lstDocentes;
    private javax.swing.JList<String> lstEstudiantes;
    private javax.swing.JTextField txtCupo;
    private javax.swing.JTextField txtFechaFin;
    private javax.swing.JTextField txtFechaInicio;
    private javax.swing.JTextField txtFechaPublicacion;
    private javax.swing.JTextField txtInscriptos;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JSeparator usersSeparator1;
    private javax.swing.JSeparator usersSeparator2;
    private javax.swing.JSeparator usersSeparator3;
    private javax.swing.JSeparator usersSeparator4;
    private javax.swing.JSeparator usersSeparator5;
    private javax.swing.JSeparator usersSeparator6;
    private javax.swing.JSeparator usersSeparator7;
    private javax.swing.JSeparator usersSeparator8;
    private javax.swing.JSeparator usersSeparator9;
    // End of variables declaration//GEN-END:variables
}
